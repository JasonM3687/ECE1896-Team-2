#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_home_btn_clicked();

    void on_cv_btn_clicked();

    void on_neural_btn_clicked();

    void on_database_btn_clicked();

    void on_refresh_btn_clicked();

    void on_correctBtn_clicked();

    void on_incorrectBtn_clicked();

private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
