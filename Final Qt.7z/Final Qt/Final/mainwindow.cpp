#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPixmap>
#include <QTextStream>
#include <QFile>
#include <QMessageBox>
#include <QCoreApplication>
#include <QDebug>
#include <algorithm>
#include <QPair>

struct greater
{
    template<class T>
    bool operator()(T const &a, T const &b) const { return a > b; }
};



double num_correct = 1;
double total_entries = 1;
double percent;
double file_data[100];
int num_digits;
//n is the current digit you viewing. set to 2 bc 1 is initialized
int n = 2;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    QPixmap ml_img("C:/Users/deanw/Documents/04_Senior_Year/2nd_Semester/ECE_1896/ECE1896-Team-2/Final Qt/Icons/ml.jpg");
    ui->ml_image->setPixmap(ml_img.scaled(300,200,Qt::KeepAspectRatio));


    //check numDigits to see how many were detected
    QFile numDigitsFile("C:/Users/deanw/Documents/04_Senior_Year/2nd_Semester/ECE_1896/ECE1896-Team-2/Midterm/numDigits.txt");
    if (!numDigitsFile.open(QFile::ReadOnly | QFile::Text))
    {
        QMessageBox::warning(this,"title","file not open");
    }
    QTextStream digitStream(&numDigitsFile);

    QString digitData = digitStream.readAll();
    num_digits = digitData.toInt();
    numDigitsFile.close();



    //read all small images even if not there
    QPixmap small1("C:/Users/deanw/Documents/04_Senior_Year/2nd_Semester/ECE_1896/ECE1896-Team-2/Midterm/Pictures/7.jpg");
    QPixmap small2("C:/Users/deanw/Documents/04_Senior_Year/2nd_Semester/ECE_1896/ECE1896-Team-2/Midterm/Pictures/0.jpg");
    QPixmap small3("C:/Users/deanw/Documents/04_Senior_Year/2nd_Semester/ECE_1896/ECE1896-Team-2/Midterm/Pictures/1.jpg");
    QPixmap small4("C:/Users/deanw/Documents/04_Senior_Year/2nd_Semester/ECE_1896/ECE1896-Team-2/Midterm/Pictures/7.jpg");
    QPixmap small5("C:/Users/deanw/Documents/04_Senior_Year/2nd_Semester/ECE_1896/ECE1896-Team-2/Midterm/Pictures/0.jpg");
    QPixmap small6("C:/Users/deanw/Documents/04_Senior_Year/2nd_Semester/ECE_1896/ECE1896-Team-2/Midterm/Pictures/1.jpg");
    QPixmap small7("C:/Users/deanw/Documents/04_Senior_Year/2nd_Semester/ECE_1896/ECE1896-Team-2/Midterm/Pictures/7.jpg");
    QPixmap small8("C:/Users/deanw/Documents/04_Senior_Year/2nd_Semester/ECE_1896/ECE1896-Team-2/Midterm/Pictures/0.jpg");
    QPixmap small9("C:/Users/deanw/Documents/04_Senior_Year/2nd_Semester/ECE_1896/ECE1896-Team-2/Midterm/Pictures/1.jpg");
    QPixmap small10("C:/Users/deanw/Documents/04_Senior_Year/2nd_Semester/ECE_1896/ECE1896-Team-2/Midterm/Pictures/1.jpg");


    //read in array data once per refresh
    int fileIndex=0;
    QFile file("C:/Users/deanw/Documents/04_Senior_Year/2nd_Semester/ECE_1896/ECE1896-Team-2/Midterm/Sample.txt");
    if (!file.open(QFile::ReadOnly | QFile::Text))
    {
        QMessageBox::warning(this,"title","file not open");
    }
    QTextStream stream(&file);

    while (!stream.atEnd())
    {
        QString line = stream.readLine();
        file_data[fileIndex] = line.toDouble();
        fileIndex++;
    }
    file.close();


    //DO N=1 STUFF TO INITIALIZE
    ui->you_wrote_pic->setPixmap(small1.scaled(350,250,Qt::KeepAspectRatio));

    QString viewing,total;
    viewing.setNum(1);
    total.setNum(num_digits);
    ui->currently_viewing->setText("Currently Viewing: Image " + viewing + " of " + total);

    //CREATE OUR MINI ARRAY
    QList<QPair<double,int> > array;
    for (int i = 0; i < 10; i++)
    {
        array.append(qMakePair(file_data[i],i));
    }
    // Ordering ascending
    std::sort(array.begin(), array.end(),greater());

    QString s,s2,s3;
    s.setNum(array[0].second);
    s2.setNum(array[1].second);
    s3.setNum(array[2].second);

    ui->prob_Label1->setText("Probability Digit = " + s);
    ui->prob_Label2->setText("Probability Digit = " + s2);
    ui->prob_Label3->setText("Probability Digit = " + s3);

    ui->progressBar_1->setValue((array[0].first)*100);
    ui->progressBar_2->setValue((array[1].first)*100);
    ui->progressBar_3->setValue((array[2].first)*100);

    ui->lcdNumber->display(array[0].second);


    //COMPUTER VISION SCREEN
    QPixmap original("C:/Users/deanw/Documents/04_Senior_Year/2nd_Semester/ECE_1896/ECE1896-Team-2/Midterm/Pictures/Original.jpg");
    QPixmap binary("C:/Users/deanw/Documents/04_Senior_Year/2nd_Semester/ECE_1896/ECE1896-Team-2/Midterm/Pictures/Binary.jpg");
    QPixmap boxes("C:/Users/deanw/Documents/04_Senior_Year/2nd_Semester/ECE_1896/ECE1896-Team-2/Midterm/Pictures/Boxes.jpg");

    ui->step1pic->setPixmap(original.scaled(350,300,Qt::KeepAspectRatio));
    ui->step2pic->setPixmap(binary.scaled(350,300,Qt::KeepAspectRatio));
    ui->step3pic->setPixmap(boxes.scaled(350,300,Qt::KeepAspectRatio));
    ui->step4pic1->setPixmap(small1.scaled(100,100,Qt::KeepAspectRatio));
    ui->step4pic2->setPixmap(small2.scaled(100,100,Qt::KeepAspectRatio));
    ui->step4pic3->setPixmap(small3.scaled(100,100,Qt::KeepAspectRatio));
    ui->step4pic4->setPixmap(small4.scaled(100,100,Qt::KeepAspectRatio));
    ui->step4pic5->setPixmap(small5.scaled(100,100,Qt::KeepAspectRatio));
    ui->step4pic6->setPixmap(small6.scaled(100,100,Qt::KeepAspectRatio));
    ui->step4pic7->setPixmap(small7.scaled(100,100,Qt::KeepAspectRatio));
    ui->step4pic8->setPixmap(small8.scaled(100,100,Qt::KeepAspectRatio));
    ui->step4pic9->setPixmap(small9.scaled(100,100,Qt::KeepAspectRatio));
    ui->step4pic10->setPixmap(small10.scaled(100,100,Qt::KeepAspectRatio));
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_home_btn_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}


void MainWindow::on_cv_btn_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);
}


void MainWindow::on_neural_btn_clicked()
{
    ui->stackedWidget->setCurrentIndex(2);
}


void MainWindow::on_database_btn_clicked()
{
    ui->stackedWidget->setCurrentIndex(3);
}


void MainWindow::on_refresh_btn_clicked()
{
    //reset n to 2
    n=2;

    //check numDigits to see how many were detected
    QFile numDigitsFile("C:/Users/deanw/Documents/04_Senior_Year/2nd_Semester/ECE_1896/ECE1896-Team-2/Midterm/numDigits.txt");
    if (!numDigitsFile.open(QFile::ReadOnly | QFile::Text))
    {
        QMessageBox::warning(this,"title","file not open");
    }
    QTextStream digitStream(&numDigitsFile);

    QString digitData = digitStream.readAll();
    num_digits = digitData.toInt();
    numDigitsFile.close();

    //read all small images even if not there
    QPixmap small1("C:/Users/deanw/Documents/04_Senior_Year/2nd_Semester/ECE_1896/ECE1896-Team-2/Midterm/Pictures/7.jpg");
    QPixmap small2("C:/Users/deanw/Documents/04_Senior_Year/2nd_Semester/ECE_1896/ECE1896-Team-2/Midterm/Pictures/0.jpg");
    QPixmap small3("C:/Users/deanw/Documents/04_Senior_Year/2nd_Semester/ECE_1896/ECE1896-Team-2/Midterm/Pictures/1.jpg");
    QPixmap small4("C:/Users/deanw/Documents/04_Senior_Year/2nd_Semester/ECE_1896/ECE1896-Team-2/Midterm/Pictures/7.jpg");
    QPixmap small5("C:/Users/deanw/Documents/04_Senior_Year/2nd_Semester/ECE_1896/ECE1896-Team-2/Midterm/Pictures/0.jpg");
    QPixmap small6("C:/Users/deanw/Documents/04_Senior_Year/2nd_Semester/ECE_1896/ECE1896-Team-2/Midterm/Pictures/1.jpg");
    QPixmap small7("C:/Users/deanw/Documents/04_Senior_Year/2nd_Semester/ECE_1896/ECE1896-Team-2/Midterm/Pictures/7.jpg");
    QPixmap small8("C:/Users/deanw/Documents/04_Senior_Year/2nd_Semester/ECE_1896/ECE1896-Team-2/Midterm/Pictures/0.jpg");
    QPixmap small9("C:/Users/deanw/Documents/04_Senior_Year/2nd_Semester/ECE_1896/ECE1896-Team-2/Midterm/Pictures/1.jpg");
    QPixmap small10("C:/Users/deanw/Documents/04_Senior_Year/2nd_Semester/ECE_1896/ECE1896-Team-2/Midterm/Pictures/1.jpg");


    //read in array data once per refresh
    int fileIndex=0;
    QFile file("C:/Users/deanw/Documents/04_Senior_Year/2nd_Semester/ECE_1896/ECE1896-Team-2/Midterm/Sample.txt");
    if (!file.open(QFile::ReadOnly | QFile::Text))
    {
        QMessageBox::warning(this,"title","file not open");
    }
    QTextStream stream(&file);

    while (!stream.atEnd())
    {
        QString line = stream.readLine();
        file_data[fileIndex] = line.toDouble();
        fileIndex++;
    }
    file.close();

    //DO N=1 STUFF TO INITIALIZE
    ui->you_wrote_pic->setPixmap(small1.scaled(350,250,Qt::KeepAspectRatio));

    QString viewing,total;
    viewing.setNum(1);
    total.setNum(num_digits);
    ui->currently_viewing->setText("Currently Viewing: Image " + viewing + " of " + total);

    //CREATE OUR MINI ARRAY
    QList<QPair<double,int> > array;
    for (int i = 0; i < 10; i++)
    {
        array.append(qMakePair(file_data[i],i));
    }
    // Ordering ascending
    std::sort(array.begin(), array.end(),greater());

    QString s,s2,s3;
    s.setNum(array[0].second);
    s2.setNum(array[1].second);
    s3.setNum(array[2].second);

    ui->prob_Label1->setText("Probability Digit = " + s);
    ui->prob_Label2->setText("Probability Digit = " + s2);
    ui->prob_Label3->setText("Probability Digit = " + s3);

    ui->progressBar_1->setValue((array[0].first)*100);
    ui->progressBar_2->setValue((array[1].first)*100);
    ui->progressBar_3->setValue((array[2].first)*100);

    ui->lcdNumber->display(array[0].second);


    //COMPUTER VISION SCREEN
    QPixmap original("C:/Users/deanw/Documents/04_Senior_Year/2nd_Semester/ECE_1896/ECE1896-Team-2/Midterm/Pictures/Original.jpg");
    QPixmap binary("C:/Users/deanw/Documents/04_Senior_Year/2nd_Semester/ECE_1896/ECE1896-Team-2/Midterm/Pictures/Binary.jpg");
    QPixmap boxes("C:/Users/deanw/Documents/04_Senior_Year/2nd_Semester/ECE_1896/ECE1896-Team-2/Midterm/Pictures/Boxes.jpg");

    ui->step1pic->setPixmap(original.scaled(350,300,Qt::KeepAspectRatio));
    ui->step2pic->setPixmap(binary.scaled(350,300,Qt::KeepAspectRatio));
    ui->step3pic->setPixmap(boxes.scaled(350,300,Qt::KeepAspectRatio));
    ui->step4pic1->setPixmap(small1.scaled(100,100,Qt::KeepAspectRatio));
    ui->step4pic2->setPixmap(small2.scaled(100,100,Qt::KeepAspectRatio));
    ui->step4pic3->setPixmap(small3.scaled(100,100,Qt::KeepAspectRatio));
    ui->step4pic4->setPixmap(small4.scaled(100,100,Qt::KeepAspectRatio));
    ui->step4pic5->setPixmap(small5.scaled(100,100,Qt::KeepAspectRatio));
    ui->step4pic6->setPixmap(small6.scaled(100,100,Qt::KeepAspectRatio));
    ui->step4pic7->setPixmap(small7.scaled(100,100,Qt::KeepAspectRatio));
    ui->step4pic8->setPixmap(small8.scaled(100,100,Qt::KeepAspectRatio));
    ui->step4pic9->setPixmap(small9.scaled(100,100,Qt::KeepAspectRatio));
    ui->step4pic10->setPixmap(small10.scaled(100,100,Qt::KeepAspectRatio));
}



void MainWindow::on_correctBtn_clicked()
{
    if(n == (num_digits+1))
    {
        //SET TODAY ACCURACY FIRST
        num_correct++;
        total_entries++;
        percent = (num_correct/total_entries)*100;
        QString percent_str = QString::number(percent,'f',2);
        ui->today_accuracy->setText(percent_str + " %");
        n++;
    }
    else if(n <= num_digits)
    {
        //SET TODAY ACCURACY FIRST
        num_correct++;
        total_entries++;
        percent = (num_correct/total_entries)*100;
        QString percent_str = QString::number(percent,'f',2);
        ui->today_accuracy->setText(percent_str + " %");



        if(n == 2)
        {
            QPixmap small2("C:/Users/deanw/Documents/04_Senior_Year/2nd_Semester/ECE_1896/ECE1896-Team-2/Midterm/Pictures/0.jpg");
            ui->you_wrote_pic->setPixmap(small2.scaled(350,250,Qt::KeepAspectRatio));

            QString viewing,total;
            viewing.setNum(n);
            total.setNum(num_digits);
            ui->currently_viewing->setText("Currently Viewing: Image " + viewing + " of " + total);

            //CREATE OUR MINI ARRAY
            QList<QPair<double,int> > array;
            for (int i = 10; i < 20; i++)
            {
                array.append(qMakePair(file_data[i],i));
            }
            // Ordering ascending
            std::sort(array.begin(), array.end(),greater());

            QString s,s2,s3;
            s.setNum((array[0].second)-10);
            s2.setNum((array[1].second)-10);
            s3.setNum((array[2].second)-10);

            ui->prob_Label1->setText("Probability Digit = " + s);
            ui->prob_Label2->setText("Probability Digit = " + s2);
            ui->prob_Label3->setText("Probability Digit = " + s3);

            ui->progressBar_1->setValue((array[0].first)*100);
            ui->progressBar_2->setValue((array[1].first)*100);
            ui->progressBar_3->setValue((array[2].first)*100);

            ui->lcdNumber->display((array[0].second)-10);

            n++;
        }
        else if(n == 3)
        {
            QPixmap small3("C:/Users/deanw/Documents/04_Senior_Year/2nd_Semester/ECE_1896/ECE1896-Team-2/Midterm/Pictures/1.jpg");
            ui->you_wrote_pic->setPixmap(small3.scaled(350,250,Qt::KeepAspectRatio));

            QString viewing,total;
            viewing.setNum(n);
            total.setNum(num_digits);
            ui->currently_viewing->setText("Currently Viewing: Image " + viewing + " of " + total);

            //CREATE OUR MINI ARRAY
            QList<QPair<double,int> > array;
            for (int i = 20; i < 30; i++)
            {
                array.append(qMakePair(file_data[i],i));
            }
            // Ordering ascending
            std::sort(array.begin(), array.end(),greater());

            QString s,s2,s3;
            s.setNum((array[0].second)-20);
            s2.setNum((array[1].second)-20);
            s3.setNum((array[2].second)-20);

            ui->prob_Label1->setText("Probability Digit = " + s);
            ui->prob_Label2->setText("Probability Digit = " + s2);
            ui->prob_Label3->setText("Probability Digit = " + s3);

            ui->progressBar_1->setValue((array[0].first)*100);
            ui->progressBar_2->setValue((array[1].first)*100);
            ui->progressBar_3->setValue((array[2].first)*100);

            ui->lcdNumber->display((array[0].second)-20);

            n++;
        }
        else if(n == 4)
        {
            QPixmap small4("C:/Users/deanw/Documents/04_Senior_Year/2nd_Semester/ECE_1896/ECE1896-Team-2/Midterm/Pictures/1.jpg");
            ui->you_wrote_pic->setPixmap(small4.scaled(350,250,Qt::KeepAspectRatio));

            QString viewing,total;
            viewing.setNum(n);
            total.setNum(num_digits);
            ui->currently_viewing->setText("Currently Viewing: Image " + viewing + " of " + total);

            //CREATE OUR MINI ARRAY
            QList<QPair<double,int> > array;
            for (int i = 30; i < 40; i++)
            {
                array.append(qMakePair(file_data[i],i));
            }
            // Ordering ascending
            std::sort(array.begin(), array.end(),greater());

            QString s,s2,s3;
            s.setNum((array[0].second)-30);
            s2.setNum((array[1].second)-30);
            s3.setNum((array[2].second)-30);

            ui->prob_Label1->setText("Probability Digit = " + s);
            ui->prob_Label2->setText("Probability Digit = " + s2);
            ui->prob_Label3->setText("Probability Digit = " + s3);

            ui->progressBar_1->setValue((array[0].first)*100);
            ui->progressBar_2->setValue((array[1].first)*100);
            ui->progressBar_3->setValue((array[2].first)*100);

            ui->lcdNumber->display((array[0].second)-30);

            n++;
        }
        else if(n == 5)
        {
            QPixmap small5("C:/Users/deanw/Documents/04_Senior_Year/2nd_Semester/ECE_1896/ECE1896-Team-2/Midterm/Pictures/1.jpg");
            ui->you_wrote_pic->setPixmap(small5.scaled(350,250,Qt::KeepAspectRatio));

            QString viewing,total;
            viewing.setNum(n);
            total.setNum(num_digits);
            ui->currently_viewing->setText("Currently Viewing: Image " + viewing + " of " + total);

            //CREATE OUR MINI ARRAY
            QList<QPair<double,int> > array;
            for (int i = 40; i < 50; i++)
            {
                array.append(qMakePair(file_data[i],i));
            }
            // Ordering ascending
            std::sort(array.begin(), array.end(),greater());

            QString s,s2,s3;
            s.setNum((array[0].second)-40);
            s2.setNum((array[1].second)-40);
            s3.setNum((array[2].second)-40);

            ui->prob_Label1->setText("Probability Digit = " + s);
            ui->prob_Label2->setText("Probability Digit = " + s2);
            ui->prob_Label3->setText("Probability Digit = " + s3);

            ui->progressBar_1->setValue((array[0].first)*100);
            ui->progressBar_2->setValue((array[1].first)*100);
            ui->progressBar_3->setValue((array[2].first)*100);

            ui->lcdNumber->display((array[0].second)-40);

            n++;
        }
        else if(n == 6)
        {
            QPixmap small6("C:/Users/deanw/Documents/04_Senior_Year/2nd_Semester/ECE_1896/ECE1896-Team-2/Midterm/Pictures/1.jpg");
            ui->you_wrote_pic->setPixmap(small6.scaled(350,250,Qt::KeepAspectRatio));

            QString viewing,total;
            viewing.setNum(n);
            total.setNum(num_digits);
            ui->currently_viewing->setText("Currently Viewing: Image " + viewing + " of " + total);

            //CREATE OUR MINI ARRAY
            QList<QPair<double,int> > array;
            for (int i = 50; i < 60; i++)
            {
                array.append(qMakePair(file_data[i],i));
            }
            // Ordering ascending
            std::sort(array.begin(), array.end(),greater());

            QString s,s2,s3;
            s.setNum((array[0].second)-50);
            s2.setNum((array[1].second)-50);
            s3.setNum((array[2].second)-50);

            ui->prob_Label1->setText("Probability Digit = " + s);
            ui->prob_Label2->setText("Probability Digit = " + s2);
            ui->prob_Label3->setText("Probability Digit = " + s3);

            ui->progressBar_1->setValue((array[0].first)*100);
            ui->progressBar_2->setValue((array[1].first)*100);
            ui->progressBar_3->setValue((array[2].first)*100);

            ui->lcdNumber->display((array[0].second)-50);

            n++;
        }
        else if(n == 7)
        {
            QPixmap small7("C:/Users/deanw/Documents/04_Senior_Year/2nd_Semester/ECE_1896/ECE1896-Team-2/Midterm/Pictures/1.jpg");
            ui->you_wrote_pic->setPixmap(small7.scaled(350,250,Qt::KeepAspectRatio));

            QString viewing,total;
            viewing.setNum(n);
            total.setNum(num_digits);
            ui->currently_viewing->setText("Currently Viewing: Image " + viewing + " of " + total);

            //CREATE OUR MINI ARRAY
            QList<QPair<double,int> > array;
            for (int i = 60; i < 70; i++)
            {
                array.append(qMakePair(file_data[i],i));
            }
            // Ordering ascending
            std::sort(array.begin(), array.end(),greater());

            QString s,s2,s3;
            s.setNum((array[0].second)-60);
            s2.setNum((array[1].second)-60);
            s3.setNum((array[2].second)-60);

            ui->prob_Label1->setText("Probability Digit = " + s);
            ui->prob_Label2->setText("Probability Digit = " + s2);
            ui->prob_Label3->setText("Probability Digit = " + s3);

            ui->progressBar_1->setValue((array[0].first)*100);
            ui->progressBar_2->setValue((array[1].first)*100);
            ui->progressBar_3->setValue((array[2].first)*100);

            ui->lcdNumber->display((array[0].second)-60);

            n++;
        }
        else if(n == 8)
        {
            QPixmap small8("C:/Users/deanw/Documents/04_Senior_Year/2nd_Semester/ECE_1896/ECE1896-Team-2/Midterm/Pictures/1.jpg");
            ui->you_wrote_pic->setPixmap(small8.scaled(350,250,Qt::KeepAspectRatio));

            QString viewing,total;
            viewing.setNum(n);
            total.setNum(num_digits);
            ui->currently_viewing->setText("Currently Viewing: Image " + viewing + " of " + total);

            //CREATE OUR MINI ARRAY
            QList<QPair<double,int> > array;
            for (int i = 70; i < 80; i++)
            {
                array.append(qMakePair(file_data[i],i));
            }
            // Ordering ascending
            std::sort(array.begin(), array.end(),greater());

            QString s,s2,s3;
            s.setNum((array[0].second)-70);
            s2.setNum((array[1].second)-70);
            s3.setNum((array[2].second)-70);

            ui->prob_Label1->setText("Probability Digit = " + s);
            ui->prob_Label2->setText("Probability Digit = " + s2);
            ui->prob_Label3->setText("Probability Digit = " + s3);

            ui->progressBar_1->setValue((array[0].first)*100);
            ui->progressBar_2->setValue((array[1].first)*100);
            ui->progressBar_3->setValue((array[2].first)*100);

            ui->lcdNumber->display((array[0].second)-70);

            n++;
        }
        else if(n == 9)
        {
            QPixmap small9("C:/Users/deanw/Documents/04_Senior_Year/2nd_Semester/ECE_1896/ECE1896-Team-2/Midterm/Pictures/1.jpg");
            ui->you_wrote_pic->setPixmap(small9.scaled(350,250,Qt::KeepAspectRatio));

            QString viewing,total;
            viewing.setNum(n);
            total.setNum(num_digits);
            ui->currently_viewing->setText("Currently Viewing: Image " + viewing + " of " + total);

            //CREATE OUR MINI ARRAY
            QList<QPair<double,int> > array;
            for (int i = 80; i < 90; i++)
            {
                array.append(qMakePair(file_data[i],i));
            }
            // Ordering ascending
            std::sort(array.begin(), array.end(),greater());

            QString s,s2,s3;
            s.setNum((array[0].second)-80);
            s2.setNum((array[1].second)-80);
            s3.setNum((array[2].second)-80);

            ui->prob_Label1->setText("Probability Digit = " + s);
            ui->prob_Label2->setText("Probability Digit = " + s2);
            ui->prob_Label3->setText("Probability Digit = " + s3);

            ui->progressBar_1->setValue((array[0].first)*100);
            ui->progressBar_2->setValue((array[1].first)*100);
            ui->progressBar_3->setValue((array[2].first)*100);

            ui->lcdNumber->display((array[0].second)-80);

            n++;
        }
        else if(n == 10)
        {
            QPixmap small10("C:/Users/deanw/Documents/04_Senior_Year/2nd_Semester/ECE_1896/ECE1896-Team-2/Midterm/Pictures/1.jpg");
            ui->you_wrote_pic->setPixmap(small10.scaled(350,250,Qt::KeepAspectRatio));

            QString viewing,total;
            viewing.setNum(n);
            total.setNum(num_digits);
            ui->currently_viewing->setText("Currently Viewing: Image " + viewing + " of " + total);

            //CREATE OUR MINI ARRAY
            QList<QPair<double,int> > array;
            for (int i = 90; i < 100; i++)
            {
                array.append(qMakePair(file_data[i],i));
            }
            // Ordering ascending
            std::sort(array.begin(), array.end(),greater());

            QString s,s2,s3;
            s.setNum((array[0].second)-90);
            s2.setNum((array[1].second)-90);
            s3.setNum((array[2].second)-90);

            ui->prob_Label1->setText("Probability Digit = " + s);
            ui->prob_Label2->setText("Probability Digit = " + s2);
            ui->prob_Label3->setText("Probability Digit = " + s3);

            ui->progressBar_1->setValue((array[0].first)*100);
            ui->progressBar_2->setValue((array[1].first)*100);
            ui->progressBar_3->setValue((array[2].first)*100);

            ui->lcdNumber->display((array[0].second)-90);

            n++;
        }

    }
    else{

    }
}


void MainWindow::on_incorrectBtn_clicked()
{
    if(n == (num_digits+1))
    {
        //SET TODAY ACCURACY FIRST
        total_entries++;
        percent = (num_correct/total_entries)*100;
        QString percent_str = QString::number(percent,'f',2);
        ui->today_accuracy->setText(percent_str + " %");
        n++;
    }
    else if(n <= num_digits)
    {
        //SET TODAY ACCURACY FIRST
        total_entries++;
        percent = (num_correct/total_entries)*100;
        QString percent_str = QString::number(percent,'f',2);
        ui->today_accuracy->setText(percent_str + " %");



        if(n == 2)
        {
            QPixmap small2("C:/Users/deanw/Documents/04_Senior_Year/2nd_Semester/ECE_1896/ECE1896-Team-2/Midterm/Pictures/0.jpg");
            ui->you_wrote_pic->setPixmap(small2.scaled(350,250,Qt::KeepAspectRatio));

            QString viewing,total;
            viewing.setNum(n);
            total.setNum(num_digits);
            ui->currently_viewing->setText("Currently Viewing: Image " + viewing + " of " + total);

            //CREATE OUR MINI ARRAY
            QList<QPair<double,int> > array;
            for (int i = 10; i < 20; i++)
            {
                array.append(qMakePair(file_data[i],i));
            }
            // Ordering ascending
            std::sort(array.begin(), array.end(),greater());

            QString s,s2,s3;
            s.setNum((array[0].second)-10);
            s2.setNum((array[1].second)-10);
            s3.setNum((array[2].second)-10);

            ui->prob_Label1->setText("Probability Digit = " + s);
            ui->prob_Label2->setText("Probability Digit = " + s2);
            ui->prob_Label3->setText("Probability Digit = " + s3);

            ui->progressBar_1->setValue((array[0].first)*100);
            ui->progressBar_2->setValue((array[1].first)*100);
            ui->progressBar_3->setValue((array[2].first)*100);

            ui->lcdNumber->display((array[0].second)-10);

            n++;
        }
        else if(n == 3)
        {
            QPixmap small3("C:/Users/deanw/Documents/04_Senior_Year/2nd_Semester/ECE_1896/ECE1896-Team-2/Midterm/Pictures/1.jpg");
            ui->you_wrote_pic->setPixmap(small3.scaled(350,250,Qt::KeepAspectRatio));

            QString viewing,total;
            viewing.setNum(n);
            total.setNum(num_digits);
            ui->currently_viewing->setText("Currently Viewing: Image " + viewing + " of " + total);

            //CREATE OUR MINI ARRAY
            QList<QPair<double,int> > array;
            for (int i = 20; i < 30; i++)
            {
                array.append(qMakePair(file_data[i],i));
            }
            // Ordering ascending
            std::sort(array.begin(), array.end(),greater());

            QString s,s2,s3;
            s.setNum((array[0].second)-20);
            s2.setNum((array[1].second)-20);
            s3.setNum((array[2].second)-20);

            ui->prob_Label1->setText("Probability Digit = " + s);
            ui->prob_Label2->setText("Probability Digit = " + s2);
            ui->prob_Label3->setText("Probability Digit = " + s3);

            ui->progressBar_1->setValue((array[0].first)*100);
            ui->progressBar_2->setValue((array[1].first)*100);
            ui->progressBar_3->setValue((array[2].first)*100);

            ui->lcdNumber->display((array[0].second)-20);

            n++;
        }
        else if(n == 4)
        {
            QPixmap small4("C:/Users/deanw/Documents/04_Senior_Year/2nd_Semester/ECE_1896/ECE1896-Team-2/Midterm/Pictures/1.jpg");
            ui->you_wrote_pic->setPixmap(small4.scaled(350,250,Qt::KeepAspectRatio));

            QString viewing,total;
            viewing.setNum(n);
            total.setNum(num_digits);
            ui->currently_viewing->setText("Currently Viewing: Image " + viewing + " of " + total);

            //CREATE OUR MINI ARRAY
            QList<QPair<double,int> > array;
            for (int i = 30; i < 40; i++)
            {
                array.append(qMakePair(file_data[i],i));
            }
            // Ordering ascending
            std::sort(array.begin(), array.end(),greater());

            QString s,s2,s3;
            s.setNum((array[0].second)-30);
            s2.setNum((array[1].second)-30);
            s3.setNum((array[2].second)-30);

            ui->prob_Label1->setText("Probability Digit = " + s);
            ui->prob_Label2->setText("Probability Digit = " + s2);
            ui->prob_Label3->setText("Probability Digit = " + s3);

            ui->progressBar_1->setValue((array[0].first)*100);
            ui->progressBar_2->setValue((array[1].first)*100);
            ui->progressBar_3->setValue((array[2].first)*100);

            ui->lcdNumber->display((array[0].second)-30);

            n++;
        }
        else if(n == 5)
        {
            QPixmap small5("C:/Users/deanw/Documents/04_Senior_Year/2nd_Semester/ECE_1896/ECE1896-Team-2/Midterm/Pictures/1.jpg");
            ui->you_wrote_pic->setPixmap(small5.scaled(350,250,Qt::KeepAspectRatio));

            QString viewing,total;
            viewing.setNum(n);
            total.setNum(num_digits);
            ui->currently_viewing->setText("Currently Viewing: Image " + viewing + " of " + total);

            //CREATE OUR MINI ARRAY
            QList<QPair<double,int> > array;
            for (int i = 40; i < 50; i++)
            {
                array.append(qMakePair(file_data[i],i));
            }
            // Ordering ascending
            std::sort(array.begin(), array.end(),greater());

            QString s,s2,s3;
            s.setNum((array[0].second)-40);
            s2.setNum((array[1].second)-40);
            s3.setNum((array[2].second)-40);

            ui->prob_Label1->setText("Probability Digit = " + s);
            ui->prob_Label2->setText("Probability Digit = " + s2);
            ui->prob_Label3->setText("Probability Digit = " + s3);

            ui->progressBar_1->setValue((array[0].first)*100);
            ui->progressBar_2->setValue((array[1].first)*100);
            ui->progressBar_3->setValue((array[2].first)*100);

            ui->lcdNumber->display((array[0].second)-40);

            n++;
        }
        else if(n == 6)
        {
            QPixmap small6("C:/Users/deanw/Documents/04_Senior_Year/2nd_Semester/ECE_1896/ECE1896-Team-2/Midterm/Pictures/1.jpg");
            ui->you_wrote_pic->setPixmap(small6.scaled(350,250,Qt::KeepAspectRatio));

            QString viewing,total;
            viewing.setNum(n);
            total.setNum(num_digits);
            ui->currently_viewing->setText("Currently Viewing: Image " + viewing + " of " + total);

            //CREATE OUR MINI ARRAY
            QList<QPair<double,int> > array;
            for (int i = 50; i < 60; i++)
            {
                array.append(qMakePair(file_data[i],i));
            }
            // Ordering ascending
            std::sort(array.begin(), array.end(),greater());

            QString s,s2,s3;
            s.setNum((array[0].second)-50);
            s2.setNum((array[1].second)-50);
            s3.setNum((array[2].second)-50);

            ui->prob_Label1->setText("Probability Digit = " + s);
            ui->prob_Label2->setText("Probability Digit = " + s2);
            ui->prob_Label3->setText("Probability Digit = " + s3);

            ui->progressBar_1->setValue((array[0].first)*100);
            ui->progressBar_2->setValue((array[1].first)*100);
            ui->progressBar_3->setValue((array[2].first)*100);

            ui->lcdNumber->display((array[0].second)-50);

            n++;
        }
        else if(n == 7)
        {
            QPixmap small7("C:/Users/deanw/Documents/04_Senior_Year/2nd_Semester/ECE_1896/ECE1896-Team-2/Midterm/Pictures/1.jpg");
            ui->you_wrote_pic->setPixmap(small7.scaled(350,250,Qt::KeepAspectRatio));

            QString viewing,total;
            viewing.setNum(n);
            total.setNum(num_digits);
            ui->currently_viewing->setText("Currently Viewing: Image " + viewing + " of " + total);

            //CREATE OUR MINI ARRAY
            QList<QPair<double,int> > array;
            for (int i = 60; i < 70; i++)
            {
                array.append(qMakePair(file_data[i],i));
            }
            // Ordering ascending
            std::sort(array.begin(), array.end(),greater());

            QString s,s2,s3;
            s.setNum((array[0].second)-60);
            s2.setNum((array[1].second)-60);
            s3.setNum((array[2].second)-60);

            ui->prob_Label1->setText("Probability Digit = " + s);
            ui->prob_Label2->setText("Probability Digit = " + s2);
            ui->prob_Label3->setText("Probability Digit = " + s3);

            ui->progressBar_1->setValue((array[0].first)*100);
            ui->progressBar_2->setValue((array[1].first)*100);
            ui->progressBar_3->setValue((array[2].first)*100);

            ui->lcdNumber->display((array[0].second)-60);

            n++;
        }
        else if(n == 8)
        {
            QPixmap small8("C:/Users/deanw/Documents/04_Senior_Year/2nd_Semester/ECE_1896/ECE1896-Team-2/Midterm/Pictures/1.jpg");
            ui->you_wrote_pic->setPixmap(small8.scaled(350,250,Qt::KeepAspectRatio));

            QString viewing,total;
            viewing.setNum(n);
            total.setNum(num_digits);
            ui->currently_viewing->setText("Currently Viewing: Image " + viewing + " of " + total);

            //CREATE OUR MINI ARRAY
            QList<QPair<double,int> > array;
            for (int i = 70; i < 80; i++)
            {
                array.append(qMakePair(file_data[i],i));
            }
            // Ordering ascending
            std::sort(array.begin(), array.end(),greater());

            QString s,s2,s3;
            s.setNum((array[0].second)-70);
            s2.setNum((array[1].second)-70);
            s3.setNum((array[2].second)-70);

            ui->prob_Label1->setText("Probability Digit = " + s);
            ui->prob_Label2->setText("Probability Digit = " + s2);
            ui->prob_Label3->setText("Probability Digit = " + s3);

            ui->progressBar_1->setValue((array[0].first)*100);
            ui->progressBar_2->setValue((array[1].first)*100);
            ui->progressBar_3->setValue((array[2].first)*100);

            ui->lcdNumber->display((array[0].second)-70);

            n++;
        }
        else if(n == 9)
        {
            QPixmap small9("C:/Users/deanw/Documents/04_Senior_Year/2nd_Semester/ECE_1896/ECE1896-Team-2/Midterm/Pictures/1.jpg");
            ui->you_wrote_pic->setPixmap(small9.scaled(350,250,Qt::KeepAspectRatio));

            QString viewing,total;
            viewing.setNum(n);
            total.setNum(num_digits);
            ui->currently_viewing->setText("Currently Viewing: Image " + viewing + " of " + total);

            //CREATE OUR MINI ARRAY
            QList<QPair<double,int> > array;
            for (int i = 80; i < 90; i++)
            {
                array.append(qMakePair(file_data[i],i));
            }
            // Ordering ascending
            std::sort(array.begin(), array.end(),greater());

            QString s,s2,s3;
            s.setNum((array[0].second)-80);
            s2.setNum((array[1].second)-80);
            s3.setNum((array[2].second)-80);

            ui->prob_Label1->setText("Probability Digit = " + s);
            ui->prob_Label2->setText("Probability Digit = " + s2);
            ui->prob_Label3->setText("Probability Digit = " + s3);

            ui->progressBar_1->setValue((array[0].first)*100);
            ui->progressBar_2->setValue((array[1].first)*100);
            ui->progressBar_3->setValue((array[2].first)*100);

            ui->lcdNumber->display((array[0].second)-80);

            n++;
        }
        else if(n == 10)
        {
            QPixmap small10("C:/Users/deanw/Documents/04_Senior_Year/2nd_Semester/ECE_1896/ECE1896-Team-2/Midterm/Pictures/1.jpg");
            ui->you_wrote_pic->setPixmap(small10.scaled(350,250,Qt::KeepAspectRatio));

            QString viewing,total;
            viewing.setNum(n);
            total.setNum(num_digits);
            ui->currently_viewing->setText("Currently Viewing: Image " + viewing + " of " + total);

            //CREATE OUR MINI ARRAY
            QList<QPair<double,int> > array;
            for (int i = 90; i < 100; i++)
            {
                array.append(qMakePair(file_data[i],i));
            }
            // Ordering ascending
            std::sort(array.begin(), array.end(),greater());

            QString s,s2,s3;
            s.setNum((array[0].second)-90);
            s2.setNum((array[1].second)-90);
            s3.setNum((array[2].second)-90);

            ui->prob_Label1->setText("Probability Digit = " + s);
            ui->prob_Label2->setText("Probability Digit = " + s2);
            ui->prob_Label3->setText("Probability Digit = " + s3);

            ui->progressBar_1->setValue((array[0].first)*100);
            ui->progressBar_2->setValue((array[1].first)*100);
            ui->progressBar_3->setValue((array[2].first)*100);

            ui->lcdNumber->display((array[0].second)-90);

            n++;
        }

    }

}

