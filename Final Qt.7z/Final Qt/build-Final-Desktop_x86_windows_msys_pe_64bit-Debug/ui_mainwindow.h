/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLCDNumber>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QHBoxLayout *horizontalLayout;
    QWidget *leftMenu;
    QVBoxLayout *verticalLayout;
    QWidget *widget_4;
    QVBoxLayout *verticalLayout_4;
    QLabel *ml_image;
    QWidget *widget;
    QVBoxLayout *verticalLayout_2;
    QPushButton *home_btn;
    QPushButton *cv_btn;
    QPushButton *neural_btn;
    QPushButton *database_btn;
    QSpacerItem *verticalSpacer;
    QWidget *widget_3;
    QVBoxLayout *verticalLayout_3;
    QPushButton *refresh_btn;
    QPushButton *pushButton_6;
    QWidget *main;
    QVBoxLayout *verticalLayout_5;
    QStackedWidget *stackedWidget;
    QWidget *home_pg;
    QVBoxLayout *verticalLayout_6;
    QWidget *currentViewing;
    QHBoxLayout *horizontalLayout_7;
    QPushButton *eye;
    QLabel *currently_viewing;
    QSpacerItem *horizontalSpacer;
    QSpacerItem *verticalSpacer_6;
    QWidget *top_info;
    QHBoxLayout *horizontalLayout_2;
    QWidget *you_wrote;
    QVBoxLayout *verticalLayout_7;
    QLabel *youWrote;
    QLabel *you_wrote_pic;
    QSpacerItem *horizontalSpacer_4;
    QWidget *prob;
    QFormLayout *formLayout;
    QLabel *ourGuesses;
    QSpacerItem *verticalSpacer_2;
    QLabel *prob_Label1;
    QLabel *prob_Label2;
    QLabel *prob_Label3;
    QSpacerItem *verticalSpacer_3;
    QSpacerItem *verticalSpacer_4;
    QProgressBar *progressBar_1;
    QProgressBar *progressBar_2;
    QProgressBar *progressBar_3;
    QSpacerItem *horizontalSpacer_3;
    QWidget *result;
    QVBoxLayout *verticalLayout_8;
    QLabel *finalResult;
    QWidget *widget_9;
    QHBoxLayout *horizontalLayout_10;
    QLCDNumber *lcdNumber;
    QSpacerItem *horizontalSpacer_2;
    QSpacerItem *verticalSpacer_5;
    QWidget *latency;
    QHBoxLayout *horizontalLayout_11;
    QSpacerItem *horizontalSpacer_5;
    QWidget *latency_box;
    QHBoxLayout *horizontalLayout_12;
    QPushButton *clock;
    QLabel *label_3;
    QSpacerItem *horizontalSpacer_6;
    QWidget *is_correct;
    QHBoxLayout *horizontalLayout_3;
    QPushButton *correctBtn;
    QPushButton *incorrectBtn;
    QWidget *accuracy;
    QVBoxLayout *verticalLayout_9;
    QLabel *label;
    QLabel *today_accuracy;
    QWidget *cv_pg;
    QVBoxLayout *verticalLayout_10;
    QWidget *heresHow;
    QHBoxLayout *horizontalLayout_8;
    QLabel *howLabel;
    QWidget *widget_2;
    QHBoxLayout *horizontalLayout_4;
    QWidget *step1;
    QVBoxLayout *verticalLayout_11;
    QLabel *label_5;
    QLabel *step1pic;
    QWidget *step2;
    QVBoxLayout *verticalLayout_12;
    QLabel *label_6;
    QLabel *step2pic;
    QWidget *step3;
    QVBoxLayout *verticalLayout_13;
    QLabel *label_7;
    QLabel *step3pic;
    QWidget *step4;
    QVBoxLayout *verticalLayout_14;
    QLabel *label_8;
    QWidget *widget_5;
    QHBoxLayout *horizontalLayout_5;
    QLabel *step4pic1;
    QLabel *step4pic2;
    QLabel *step4pic3;
    QLabel *step4pic4;
    QLabel *step4pic5;
    QWidget *widget_6;
    QHBoxLayout *horizontalLayout_6;
    QLabel *step4pic6;
    QLabel *step4pic7;
    QLabel *step4pic8;
    QLabel *step4pic9;
    QLabel *step4pic10;
    QWidget *neural_pg;
    QVBoxLayout *verticalLayout_15;
    QWidget *widget_7;
    QHBoxLayout *horizontalLayout_9;
    QLabel *anExample;
    QWidget *widget_8;
    QVBoxLayout *verticalLayout_16;
    QLabel *label_2;
    QWidget *database_pg;
    QLabel *label_4;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1039, 664);
        MainWindow->setStyleSheet(QString::fromUtf8("*{\n"
"	border: none;\n"
"	background-color: transparent;\n"
"	padding: 0;\n"
"	margin:0;\n"
"}\n"
"\n"
"#centralwidget{\n"
"	background-color: #fff\n"
"}\n"
"#leftMenu{\n"
"	background-color: #16191d\n"
"}\n"
"QPushButton{\n"
"	text-align: left;\n"
"	padding: 2px 5px;\n"
"}"));
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        horizontalLayout = new QHBoxLayout(centralwidget);
        horizontalLayout->setSpacing(0);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        leftMenu = new QWidget(centralwidget);
        leftMenu->setObjectName(QString::fromUtf8("leftMenu"));
        leftMenu->setStyleSheet(QString::fromUtf8("*{\n"
"	color: #fff;\n"
"}"));
        verticalLayout = new QVBoxLayout(leftMenu);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        widget_4 = new QWidget(leftMenu);
        widget_4->setObjectName(QString::fromUtf8("widget_4"));
        verticalLayout_4 = new QVBoxLayout(widget_4);
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        ml_image = new QLabel(widget_4);
        ml_image->setObjectName(QString::fromUtf8("ml_image"));
        ml_image->setLayoutDirection(Qt::LeftToRight);
        ml_image->setAlignment(Qt::AlignCenter);

        verticalLayout_4->addWidget(ml_image);


        verticalLayout->addWidget(widget_4, 0, Qt::AlignTop);

        widget = new QWidget(leftMenu);
        widget->setObjectName(QString::fromUtf8("widget"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(widget->sizePolicy().hasHeightForWidth());
        widget->setSizePolicy(sizePolicy);
        verticalLayout_2 = new QVBoxLayout(widget);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        home_btn = new QPushButton(widget);
        home_btn->setObjectName(QString::fromUtf8("home_btn"));
        home_btn->setStyleSheet(QString::fromUtf8("home_btn{\n"
"	font: 20pt \"Segoe UI\";\n"
"}\n"
""));
        QIcon icon;
        icon.addFile(QString::fromUtf8("../Icons/home.svg"), QSize(), QIcon::Normal, QIcon::Off);
        home_btn->setIcon(icon);
        home_btn->setIconSize(QSize(36, 36));

        verticalLayout_2->addWidget(home_btn);

        cv_btn = new QPushButton(widget);
        cv_btn->setObjectName(QString::fromUtf8("cv_btn"));
        QIcon icon1;
        icon1.addFile(QString::fromUtf8("../Icons/camera.svg"), QSize(), QIcon::Normal, QIcon::Off);
        cv_btn->setIcon(icon1);
        cv_btn->setIconSize(QSize(36, 36));

        verticalLayout_2->addWidget(cv_btn);

        neural_btn = new QPushButton(widget);
        neural_btn->setObjectName(QString::fromUtf8("neural_btn"));
        QIcon icon2;
        icon2.addFile(QString::fromUtf8("../Icons/share-2.svg"), QSize(), QIcon::Normal, QIcon::Off);
        neural_btn->setIcon(icon2);
        neural_btn->setIconSize(QSize(36, 36));

        verticalLayout_2->addWidget(neural_btn);

        database_btn = new QPushButton(widget);
        database_btn->setObjectName(QString::fromUtf8("database_btn"));
        QIcon icon3;
        icon3.addFile(QString::fromUtf8("../Icons/server.svg"), QSize(), QIcon::Normal, QIcon::Off);
        database_btn->setIcon(icon3);
        database_btn->setIconSize(QSize(36, 36));

        verticalLayout_2->addWidget(database_btn);


        verticalLayout->addWidget(widget);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);

        widget_3 = new QWidget(leftMenu);
        widget_3->setObjectName(QString::fromUtf8("widget_3"));
        verticalLayout_3 = new QVBoxLayout(widget_3);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        refresh_btn = new QPushButton(widget_3);
        refresh_btn->setObjectName(QString::fromUtf8("refresh_btn"));
        QIcon icon4;
        icon4.addFile(QString::fromUtf8("../Icons/refresh-cw.svg"), QSize(), QIcon::Normal, QIcon::Off);
        refresh_btn->setIcon(icon4);
        refresh_btn->setIconSize(QSize(36, 36));

        verticalLayout_3->addWidget(refresh_btn);

        pushButton_6 = new QPushButton(widget_3);
        pushButton_6->setObjectName(QString::fromUtf8("pushButton_6"));
        QIcon icon5;
        icon5.addFile(QString::fromUtf8("../Icons/x.svg"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_6->setIcon(icon5);
        pushButton_6->setIconSize(QSize(36, 36));

        verticalLayout_3->addWidget(pushButton_6);


        verticalLayout->addWidget(widget_3, 0, Qt::AlignBottom);


        horizontalLayout->addWidget(leftMenu, 0, Qt::AlignLeft);

        main = new QWidget(centralwidget);
        main->setObjectName(QString::fromUtf8("main"));
        verticalLayout_5 = new QVBoxLayout(main);
        verticalLayout_5->setSpacing(0);
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        verticalLayout_5->setContentsMargins(0, 0, 0, 0);
        stackedWidget = new QStackedWidget(main);
        stackedWidget->setObjectName(QString::fromUtf8("stackedWidget"));
        home_pg = new QWidget();
        home_pg->setObjectName(QString::fromUtf8("home_pg"));
        verticalLayout_6 = new QVBoxLayout(home_pg);
        verticalLayout_6->setObjectName(QString::fromUtf8("verticalLayout_6"));
        verticalLayout_6->setContentsMargins(0, 0, 0, 0);
        currentViewing = new QWidget(home_pg);
        currentViewing->setObjectName(QString::fromUtf8("currentViewing"));
        currentViewing->setStyleSheet(QString::fromUtf8("#currentViewing{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0.0284091 rgba(52, 188, 218, 255), stop:1 rgba(47, 50, 233, 255));\n"
"}"));
        horizontalLayout_7 = new QHBoxLayout(currentViewing);
        horizontalLayout_7->setSpacing(0);
        horizontalLayout_7->setObjectName(QString::fromUtf8("horizontalLayout_7"));
        horizontalLayout_7->setContentsMargins(6, 6, -1, -1);
        eye = new QPushButton(currentViewing);
        eye->setObjectName(QString::fromUtf8("eye"));
        QSizePolicy sizePolicy1(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(eye->sizePolicy().hasHeightForWidth());
        eye->setSizePolicy(sizePolicy1);
        QIcon icon6;
        icon6.addFile(QString::fromUtf8("../Icons/eye.svg"), QSize(), QIcon::Normal, QIcon::Off);
        eye->setIcon(icon6);
        eye->setIconSize(QSize(60, 60));

        horizontalLayout_7->addWidget(eye, 0, Qt::AlignLeft);

        currently_viewing = new QLabel(currentViewing);
        currently_viewing->setObjectName(QString::fromUtf8("currently_viewing"));
        currently_viewing->setStyleSheet(QString::fromUtf8("#currently_viewing{\n"
"	color: #ffffff;\n"
"	font: 22pt \"Eras Demi ITC\";\n"
"}"));

        horizontalLayout_7->addWidget(currently_viewing);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_7->addItem(horizontalSpacer);


        verticalLayout_6->addWidget(currentViewing);

        verticalSpacer_6 = new QSpacerItem(20, 50, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout_6->addItem(verticalSpacer_6);

        top_info = new QWidget(home_pg);
        top_info->setObjectName(QString::fromUtf8("top_info"));
        horizontalLayout_2 = new QHBoxLayout(top_info);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        you_wrote = new QWidget(top_info);
        you_wrote->setObjectName(QString::fromUtf8("you_wrote"));
        you_wrote->setStyleSheet(QString::fromUtf8("#you_wrote{\n"
"	background-color: #393e40;\n"
"	border-radius: 20px;\n"
"	color: #ffffff;\n"
"}"));
        verticalLayout_7 = new QVBoxLayout(you_wrote);
        verticalLayout_7->setObjectName(QString::fromUtf8("verticalLayout_7"));
        youWrote = new QLabel(you_wrote);
        youWrote->setObjectName(QString::fromUtf8("youWrote"));
        youWrote->setAlignment(Qt::AlignCenter);

        verticalLayout_7->addWidget(youWrote, 0, Qt::AlignTop);

        you_wrote_pic = new QLabel(you_wrote);
        you_wrote_pic->setObjectName(QString::fromUtf8("you_wrote_pic"));
        sizePolicy.setHeightForWidth(you_wrote_pic->sizePolicy().hasHeightForWidth());
        you_wrote_pic->setSizePolicy(sizePolicy);
        you_wrote_pic->setAlignment(Qt::AlignCenter);

        verticalLayout_7->addWidget(you_wrote_pic);


        horizontalLayout_2->addWidget(you_wrote);

        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_4);

        prob = new QWidget(top_info);
        prob->setObjectName(QString::fromUtf8("prob"));
        prob->setStyleSheet(QString::fromUtf8("#prob{\n"
"	font: 16pt \"Segoe UI\";\n"
"	background-color: #393e40;\n"
"	border-radius: 20px;\n"
"	color: #ffffff;\n"
"}"));
        formLayout = new QFormLayout(prob);
        formLayout->setObjectName(QString::fromUtf8("formLayout"));
        ourGuesses = new QLabel(prob);
        ourGuesses->setObjectName(QString::fromUtf8("ourGuesses"));
        ourGuesses->setAlignment(Qt::AlignCenter);

        formLayout->setWidget(0, QFormLayout::SpanningRole, ourGuesses);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Fixed);

        formLayout->setItem(1, QFormLayout::LabelRole, verticalSpacer_2);

        prob_Label1 = new QLabel(prob);
        prob_Label1->setObjectName(QString::fromUtf8("prob_Label1"));
        prob_Label1->setStyleSheet(QString::fromUtf8("#prob_Label1{\n"
"	font: 20pt \"Segoe UI\";\n"
"	color: #ffffff;\n"
"}"));

        formLayout->setWidget(2, QFormLayout::LabelRole, prob_Label1);

        prob_Label2 = new QLabel(prob);
        prob_Label2->setObjectName(QString::fromUtf8("prob_Label2"));
        prob_Label2->setStyleSheet(QString::fromUtf8("#prob_Label2{\n"
"	font: 20pt \"Segoe UI\";\n"
"	color: #ffffff;\n"
"}"));

        formLayout->setWidget(5, QFormLayout::LabelRole, prob_Label2);

        prob_Label3 = new QLabel(prob);
        prob_Label3->setObjectName(QString::fromUtf8("prob_Label3"));
        prob_Label3->setStyleSheet(QString::fromUtf8("#prob_Label3{\n"
"	font: 20pt \"Segoe UI\";\n"
"	color: #ffffff;\n"
"}"));

        formLayout->setWidget(8, QFormLayout::LabelRole, prob_Label3);

        verticalSpacer_3 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Fixed);

        formLayout->setItem(7, QFormLayout::LabelRole, verticalSpacer_3);

        verticalSpacer_4 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Fixed);

        formLayout->setItem(4, QFormLayout::LabelRole, verticalSpacer_4);

        progressBar_1 = new QProgressBar(prob);
        progressBar_1->setObjectName(QString::fromUtf8("progressBar_1"));
        QSizePolicy sizePolicy2(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(progressBar_1->sizePolicy().hasHeightForWidth());
        progressBar_1->setSizePolicy(sizePolicy2);
        progressBar_1->setStyleSheet(QString::fromUtf8("QProgressBar{\n"
"	background-color: rgb(255, 255, 255);\n"
"	color: rgb(0, 0, 0);\n"
"	border-style: solid;\n"
"   border-radius: 10px;\n"
"	text-align: center;\n"
"	\n"
"	font: italic 18pt \"Calibri\";\n"
"}\n"
"\n"
"QProgressBar::chunk{\n"
"   border-radius: 10px;\n"
"	background-color: rgb(0, 255, 30);\n"
"\n"
"}"));
        progressBar_1->setValue(24);

        formLayout->setWidget(3, QFormLayout::SpanningRole, progressBar_1);

        progressBar_2 = new QProgressBar(prob);
        progressBar_2->setObjectName(QString::fromUtf8("progressBar_2"));
        sizePolicy2.setHeightForWidth(progressBar_2->sizePolicy().hasHeightForWidth());
        progressBar_2->setSizePolicy(sizePolicy2);
        progressBar_2->setStyleSheet(QString::fromUtf8("QProgressBar{\n"
"	background-color: rgb(255, 255, 255);\n"
"	color: rgb(0, 0, 0);\n"
"	border-style: solid;\n"
"   border-radius: 10px;\n"
"	text-align: center;\n"
"	\n"
"	font: italic 18pt \"Calibri\";\n"
"}\n"
"\n"
"QProgressBar::chunk{\n"
"   border-radius: 10px;\n"
"	background-color: rgb(255, 213, 0);\n"
"\n"
"}"));
        progressBar_2->setValue(24);

        formLayout->setWidget(6, QFormLayout::SpanningRole, progressBar_2);

        progressBar_3 = new QProgressBar(prob);
        progressBar_3->setObjectName(QString::fromUtf8("progressBar_3"));
        sizePolicy2.setHeightForWidth(progressBar_3->sizePolicy().hasHeightForWidth());
        progressBar_3->setSizePolicy(sizePolicy2);
        progressBar_3->setStyleSheet(QString::fromUtf8("QProgressBar{\n"
"	background-color: rgb(255, 255, 255);\n"
"	color: rgb(0, 0, 0);\n"
"	border-style: solid;\n"
"   border-radius: 10px;\n"
"	text-align: center;\n"
"	\n"
"	font: italic 18pt \"Calibri\";\n"
"}\n"
"\n"
"QProgressBar::chunk{\n"
"   border-radius: 10px;\n"
"	background-color: rgb(255, 47, 50);\n"
"\n"
"}"));
        progressBar_3->setValue(24);

        formLayout->setWidget(9, QFormLayout::SpanningRole, progressBar_3);


        horizontalLayout_2->addWidget(prob);

        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_3);

        result = new QWidget(top_info);
        result->setObjectName(QString::fromUtf8("result"));
        result->setStyleSheet(QString::fromUtf8("#result{\n"
"	background-color: #393e40;\n"
"	border-radius: 20px;\n"
"	color: #ffffff;\n"
"}"));
        verticalLayout_8 = new QVBoxLayout(result);
        verticalLayout_8->setObjectName(QString::fromUtf8("verticalLayout_8"));
        finalResult = new QLabel(result);
        finalResult->setObjectName(QString::fromUtf8("finalResult"));
        finalResult->setAlignment(Qt::AlignCenter);

        verticalLayout_8->addWidget(finalResult, 0, Qt::AlignTop);

        widget_9 = new QWidget(result);
        widget_9->setObjectName(QString::fromUtf8("widget_9"));
        sizePolicy.setHeightForWidth(widget_9->sizePolicy().hasHeightForWidth());
        widget_9->setSizePolicy(sizePolicy);
        widget_9->setLayoutDirection(Qt::LeftToRight);
        horizontalLayout_10 = new QHBoxLayout(widget_9);
        horizontalLayout_10->setObjectName(QString::fromUtf8("horizontalLayout_10"));
        lcdNumber = new QLCDNumber(widget_9);
        lcdNumber->setObjectName(QString::fromUtf8("lcdNumber"));
        sizePolicy.setHeightForWidth(lcdNumber->sizePolicy().hasHeightForWidth());
        lcdNumber->setSizePolicy(sizePolicy);
        lcdNumber->setStyleSheet(QString::fromUtf8("#lcdNumber{\n"
"	color: #33c5ff;\n"
"}"));
        lcdNumber->setFrameShape(QFrame::NoFrame);
        lcdNumber->setFrameShadow(QFrame::Plain);
        lcdNumber->setDigitCount(2);
        lcdNumber->setSegmentStyle(QLCDNumber::Flat);

        horizontalLayout_10->addWidget(lcdNumber);

        horizontalSpacer_2 = new QSpacerItem(150, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_10->addItem(horizontalSpacer_2);


        verticalLayout_8->addWidget(widget_9);


        horizontalLayout_2->addWidget(result);


        verticalLayout_6->addWidget(top_info);

        verticalSpacer_5 = new QSpacerItem(20, 70, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout_6->addItem(verticalSpacer_5);

        latency = new QWidget(home_pg);
        latency->setObjectName(QString::fromUtf8("latency"));
        horizontalLayout_11 = new QHBoxLayout(latency);
        horizontalLayout_11->setObjectName(QString::fromUtf8("horizontalLayout_11"));
        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_11->addItem(horizontalSpacer_5);

        latency_box = new QWidget(latency);
        latency_box->setObjectName(QString::fromUtf8("latency_box"));
        horizontalLayout_12 = new QHBoxLayout(latency_box);
        horizontalLayout_12->setObjectName(QString::fromUtf8("horizontalLayout_12"));
        clock = new QPushButton(latency_box);
        clock->setObjectName(QString::fromUtf8("clock"));
        QIcon icon7;
        icon7.addFile(QString::fromUtf8("../Icons/clock.svg"), QSize(), QIcon::Normal, QIcon::Off);
        clock->setIcon(icon7);
        clock->setIconSize(QSize(60, 12));

        horizontalLayout_12->addWidget(clock);

        label_3 = new QLabel(latency_box);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        horizontalLayout_12->addWidget(label_3);


        horizontalLayout_11->addWidget(latency_box);

        horizontalSpacer_6 = new QSpacerItem(40, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_11->addItem(horizontalSpacer_6);


        verticalLayout_6->addWidget(latency);

        is_correct = new QWidget(home_pg);
        is_correct->setObjectName(QString::fromUtf8("is_correct"));
        horizontalLayout_3 = new QHBoxLayout(is_correct);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        correctBtn = new QPushButton(is_correct);
        correctBtn->setObjectName(QString::fromUtf8("correctBtn"));
        QSizePolicy sizePolicy3(QSizePolicy::Minimum, QSizePolicy::Preferred);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(correctBtn->sizePolicy().hasHeightForWidth());
        correctBtn->setSizePolicy(sizePolicy3);
        correctBtn->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"	text-align: center;\n"
"	padding: 2px 5px;\n"
"	background-color: green;\n"
"	color: rgb(255, 255, 255);\n"
"	font: 20pt \"Segoe UI\";\n"
"}"));
        QIcon icon8;
        icon8.addFile(QString::fromUtf8("../Icons/check-circle.svg"), QSize(), QIcon::Normal, QIcon::Off);
        correctBtn->setIcon(icon8);
        correctBtn->setIconSize(QSize(48, 48));

        horizontalLayout_3->addWidget(correctBtn);

        incorrectBtn = new QPushButton(is_correct);
        incorrectBtn->setObjectName(QString::fromUtf8("incorrectBtn"));
        sizePolicy3.setHeightForWidth(incorrectBtn->sizePolicy().hasHeightForWidth());
        incorrectBtn->setSizePolicy(sizePolicy3);
        incorrectBtn->setStyleSheet(QString::fromUtf8("QPushButton{\n"
"	text-align: center;\n"
"	padding: 2px 5px;\n"
"	background-color: #cc1b1b;\n"
"	color: rgb(255, 255, 255);\n"
"	font: 20pt \"Segoe UI\";\n"
"}"));
        QIcon icon9;
        icon9.addFile(QString::fromUtf8("../Icons/x-square.svg"), QSize(), QIcon::Normal, QIcon::Off);
        incorrectBtn->setIcon(icon9);
        incorrectBtn->setIconSize(QSize(48, 48));

        horizontalLayout_3->addWidget(incorrectBtn);

        accuracy = new QWidget(is_correct);
        accuracy->setObjectName(QString::fromUtf8("accuracy"));
        accuracy->setStyleSheet(QString::fromUtf8("#accuracy{\n"
"	background-color: #16191d;\n"
"	border-radius: 10px;\n"
"	color: #ffffff;\n"
"	\n"
"	font: 16pt \"Segoe UI\";\n"
"}"));
        verticalLayout_9 = new QVBoxLayout(accuracy);
        verticalLayout_9->setObjectName(QString::fromUtf8("verticalLayout_9"));
        label = new QLabel(accuracy);
        label->setObjectName(QString::fromUtf8("label"));
        label->setAlignment(Qt::AlignCenter);

        verticalLayout_9->addWidget(label);

        today_accuracy = new QLabel(accuracy);
        today_accuracy->setObjectName(QString::fromUtf8("today_accuracy"));
        today_accuracy->setStyleSheet(QString::fromUtf8("#today_accuracy{\n"
"	color: #ffffff;\n"
"	\n"
"	font: italic 28pt \"Tw Cen MT\";\n"
"}"));
        today_accuracy->setAlignment(Qt::AlignCenter);

        verticalLayout_9->addWidget(today_accuracy);


        horizontalLayout_3->addWidget(accuracy);


        verticalLayout_6->addWidget(is_correct, 0, Qt::AlignBottom);

        stackedWidget->addWidget(home_pg);
        cv_pg = new QWidget();
        cv_pg->setObjectName(QString::fromUtf8("cv_pg"));
        verticalLayout_10 = new QVBoxLayout(cv_pg);
        verticalLayout_10->setObjectName(QString::fromUtf8("verticalLayout_10"));
        verticalLayout_10->setContentsMargins(0, 0, 0, 0);
        heresHow = new QWidget(cv_pg);
        heresHow->setObjectName(QString::fromUtf8("heresHow"));
        heresHow->setStyleSheet(QString::fromUtf8("#heresHow{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0.267045 rgba(255, 139, 44, 255), stop:1 rgba(255, 0, 4, 255));\n"
"}"));
        horizontalLayout_8 = new QHBoxLayout(heresHow);
        horizontalLayout_8->setObjectName(QString::fromUtf8("horizontalLayout_8"));
        howLabel = new QLabel(heresHow);
        howLabel->setObjectName(QString::fromUtf8("howLabel"));
        howLabel->setStyleSheet(QString::fromUtf8("#howLabel{\n"
"	color: #ffffff;\n"
"	font: 22pt \"Eras Demi ITC\";\n"
"}"));

        horizontalLayout_8->addWidget(howLabel);


        verticalLayout_10->addWidget(heresHow, 0, Qt::AlignTop);

        widget_2 = new QWidget(cv_pg);
        widget_2->setObjectName(QString::fromUtf8("widget_2"));
        horizontalLayout_4 = new QHBoxLayout(widget_2);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        step1 = new QWidget(widget_2);
        step1->setObjectName(QString::fromUtf8("step1"));
        step1->setStyleSheet(QString::fromUtf8("#step1{\n"
"	background-color: #7a1111;\n"
"	border-radius: 20px;\n"
"	color: #ffffff;\n"
"}"));
        verticalLayout_11 = new QVBoxLayout(step1);
        verticalLayout_11->setObjectName(QString::fromUtf8("verticalLayout_11"));
        label_5 = new QLabel(step1);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        verticalLayout_11->addWidget(label_5, 0, Qt::AlignTop);

        step1pic = new QLabel(step1);
        step1pic->setObjectName(QString::fromUtf8("step1pic"));
        step1pic->setAlignment(Qt::AlignCenter);

        verticalLayout_11->addWidget(step1pic);


        horizontalLayout_4->addWidget(step1);

        step2 = new QWidget(widget_2);
        step2->setObjectName(QString::fromUtf8("step2"));
        step2->setStyleSheet(QString::fromUtf8("#step2{\n"
"	background-color: #a1580b;\n"
"	border-radius: 20px;\n"
"	color: #ffffff;\n"
"}"));
        verticalLayout_12 = new QVBoxLayout(step2);
        verticalLayout_12->setObjectName(QString::fromUtf8("verticalLayout_12"));
        label_6 = new QLabel(step2);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        verticalLayout_12->addWidget(label_6, 0, Qt::AlignTop);

        step2pic = new QLabel(step2);
        step2pic->setObjectName(QString::fromUtf8("step2pic"));
        step2pic->setAlignment(Qt::AlignCenter);

        verticalLayout_12->addWidget(step2pic);


        horizontalLayout_4->addWidget(step2);

        step3 = new QWidget(widget_2);
        step3->setObjectName(QString::fromUtf8("step3"));
        step3->setStyleSheet(QString::fromUtf8("#step3{\n"
"	background-color: #c7c114;\n"
"	border-radius: 20px;\n"
"	color: #ffffff;\n"
"}"));
        verticalLayout_13 = new QVBoxLayout(step3);
        verticalLayout_13->setObjectName(QString::fromUtf8("verticalLayout_13"));
        label_7 = new QLabel(step3);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        verticalLayout_13->addWidget(label_7, 0, Qt::AlignTop);

        step3pic = new QLabel(step3);
        step3pic->setObjectName(QString::fromUtf8("step3pic"));
        step3pic->setAlignment(Qt::AlignCenter);

        verticalLayout_13->addWidget(step3pic);


        horizontalLayout_4->addWidget(step3);


        verticalLayout_10->addWidget(widget_2);

        step4 = new QWidget(cv_pg);
        step4->setObjectName(QString::fromUtf8("step4"));
        step4->setStyleSheet(QString::fromUtf8("#step4{\n"
"	background-color: #469912;\n"
"	border-radius: 20px;\n"
"	color: #ffffff;\n"
"}"));
        verticalLayout_14 = new QVBoxLayout(step4);
        verticalLayout_14->setObjectName(QString::fromUtf8("verticalLayout_14"));
        label_8 = new QLabel(step4);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        verticalLayout_14->addWidget(label_8, 0, Qt::AlignTop);

        widget_5 = new QWidget(step4);
        widget_5->setObjectName(QString::fromUtf8("widget_5"));
        horizontalLayout_5 = new QHBoxLayout(widget_5);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        step4pic1 = new QLabel(widget_5);
        step4pic1->setObjectName(QString::fromUtf8("step4pic1"));
        QSizePolicy sizePolicy4(QSizePolicy::Expanding, QSizePolicy::Preferred);
        sizePolicy4.setHorizontalStretch(0);
        sizePolicy4.setVerticalStretch(0);
        sizePolicy4.setHeightForWidth(step4pic1->sizePolicy().hasHeightForWidth());
        step4pic1->setSizePolicy(sizePolicy4);

        horizontalLayout_5->addWidget(step4pic1);

        step4pic2 = new QLabel(widget_5);
        step4pic2->setObjectName(QString::fromUtf8("step4pic2"));
        sizePolicy4.setHeightForWidth(step4pic2->sizePolicy().hasHeightForWidth());
        step4pic2->setSizePolicy(sizePolicy4);

        horizontalLayout_5->addWidget(step4pic2);

        step4pic3 = new QLabel(widget_5);
        step4pic3->setObjectName(QString::fromUtf8("step4pic3"));
        sizePolicy4.setHeightForWidth(step4pic3->sizePolicy().hasHeightForWidth());
        step4pic3->setSizePolicy(sizePolicy4);

        horizontalLayout_5->addWidget(step4pic3);

        step4pic4 = new QLabel(widget_5);
        step4pic4->setObjectName(QString::fromUtf8("step4pic4"));
        sizePolicy4.setHeightForWidth(step4pic4->sizePolicy().hasHeightForWidth());
        step4pic4->setSizePolicy(sizePolicy4);

        horizontalLayout_5->addWidget(step4pic4);

        step4pic5 = new QLabel(widget_5);
        step4pic5->setObjectName(QString::fromUtf8("step4pic5"));
        sizePolicy4.setHeightForWidth(step4pic5->sizePolicy().hasHeightForWidth());
        step4pic5->setSizePolicy(sizePolicy4);

        horizontalLayout_5->addWidget(step4pic5);


        verticalLayout_14->addWidget(widget_5);

        widget_6 = new QWidget(step4);
        widget_6->setObjectName(QString::fromUtf8("widget_6"));
        horizontalLayout_6 = new QHBoxLayout(widget_6);
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        step4pic6 = new QLabel(widget_6);
        step4pic6->setObjectName(QString::fromUtf8("step4pic6"));
        sizePolicy4.setHeightForWidth(step4pic6->sizePolicy().hasHeightForWidth());
        step4pic6->setSizePolicy(sizePolicy4);

        horizontalLayout_6->addWidget(step4pic6);

        step4pic7 = new QLabel(widget_6);
        step4pic7->setObjectName(QString::fromUtf8("step4pic7"));
        sizePolicy4.setHeightForWidth(step4pic7->sizePolicy().hasHeightForWidth());
        step4pic7->setSizePolicy(sizePolicy4);

        horizontalLayout_6->addWidget(step4pic7);

        step4pic8 = new QLabel(widget_6);
        step4pic8->setObjectName(QString::fromUtf8("step4pic8"));
        sizePolicy4.setHeightForWidth(step4pic8->sizePolicy().hasHeightForWidth());
        step4pic8->setSizePolicy(sizePolicy4);

        horizontalLayout_6->addWidget(step4pic8);

        step4pic9 = new QLabel(widget_6);
        step4pic9->setObjectName(QString::fromUtf8("step4pic9"));
        sizePolicy4.setHeightForWidth(step4pic9->sizePolicy().hasHeightForWidth());
        step4pic9->setSizePolicy(sizePolicy4);

        horizontalLayout_6->addWidget(step4pic9);

        step4pic10 = new QLabel(widget_6);
        step4pic10->setObjectName(QString::fromUtf8("step4pic10"));
        sizePolicy4.setHeightForWidth(step4pic10->sizePolicy().hasHeightForWidth());
        step4pic10->setSizePolicy(sizePolicy4);

        horizontalLayout_6->addWidget(step4pic10);


        verticalLayout_14->addWidget(widget_6);


        verticalLayout_10->addWidget(step4);

        stackedWidget->addWidget(cv_pg);
        neural_pg = new QWidget();
        neural_pg->setObjectName(QString::fromUtf8("neural_pg"));
        verticalLayout_15 = new QVBoxLayout(neural_pg);
        verticalLayout_15->setObjectName(QString::fromUtf8("verticalLayout_15"));
        verticalLayout_15->setContentsMargins(0, 0, 0, 0);
        widget_7 = new QWidget(neural_pg);
        widget_7->setObjectName(QString::fromUtf8("widget_7"));
        widget_7->setStyleSheet(QString::fromUtf8("#widget_7{\n"
"	background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 rgba(0, 255, 217, 255), stop:1 rgba(0, 230, 0, 255));\n"
"}"));
        horizontalLayout_9 = new QHBoxLayout(widget_7);
        horizontalLayout_9->setObjectName(QString::fromUtf8("horizontalLayout_9"));
        anExample = new QLabel(widget_7);
        anExample->setObjectName(QString::fromUtf8("anExample"));
        anExample->setStyleSheet(QString::fromUtf8("#anExample{\n"
"	color: #ffffff;\n"
"	font: 22pt \"Eras Demi ITC\";\n"
"}"));

        horizontalLayout_9->addWidget(anExample);


        verticalLayout_15->addWidget(widget_7);

        widget_8 = new QWidget(neural_pg);
        widget_8->setObjectName(QString::fromUtf8("widget_8"));
        verticalLayout_16 = new QVBoxLayout(widget_8);
        verticalLayout_16->setObjectName(QString::fromUtf8("verticalLayout_16"));
        label_2 = new QLabel(widget_8);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        verticalLayout_16->addWidget(label_2);


        verticalLayout_15->addWidget(widget_8);

        stackedWidget->addWidget(neural_pg);
        database_pg = new QWidget();
        database_pg->setObjectName(QString::fromUtf8("database_pg"));
        label_4 = new QLabel(database_pg);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(140, 140, 81, 51));
        stackedWidget->addWidget(database_pg);

        verticalLayout_5->addWidget(stackedWidget);


        horizontalLayout->addWidget(main);

        MainWindow->setCentralWidget(centralwidget);

        retranslateUi(MainWindow);
        QObject::connect(pushButton_6, SIGNAL(clicked()), MainWindow, SLOT(close()));

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        ml_image->setText(QString());
        home_btn->setText(QCoreApplication::translate("MainWindow", "Home", nullptr));
        cv_btn->setText(QCoreApplication::translate("MainWindow", "Computer Vision", nullptr));
        neural_btn->setText(QCoreApplication::translate("MainWindow", "Neural Network", nullptr));
        database_btn->setText(QCoreApplication::translate("MainWindow", "Database Test Set", nullptr));
        refresh_btn->setText(QCoreApplication::translate("MainWindow", "Refresh", nullptr));
        pushButton_6->setText(QCoreApplication::translate("MainWindow", "Exit", nullptr));
        eye->setText(QString());
        currently_viewing->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-weight:700;\">Currently Viewing: Image 1 of 3</span></p></body></html>", nullptr));
        youWrote->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:22pt; font-weight:700; color:#ffffff;\">You Wrote:</span></p></body></html>", nullptr));
        you_wrote_pic->setText(QString());
        ourGuesses->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:22pt; font-weight:700; color:#ffffff;\">Our Top Guesses:</span></p></body></html>", nullptr));
        prob_Label1->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:16pt; color:#ffffff; \">Probability Digit = 0</span></p></body></html>", nullptr));
        prob_Label2->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:16pt; color:#ffffff; \">Probability Digit = 0</span></p></body></html>", nullptr));
        prob_Label3->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:16pt; color:#ffffff; \">Probability Digit = 0</span></p></body></html>", nullptr));
        finalResult->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:22pt; font-weight:700; color:#ffffff;\">Final Result:</span></p></body></html>", nullptr));
        clock->setText(QString());
        label_3->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        correctBtn->setText(QCoreApplication::translate("MainWindow", "The above inference is \n"
"CORRECT", nullptr));
        incorrectBtn->setText(QCoreApplication::translate("MainWindow", "The above inference is\n"
"INCORRECT", nullptr));
        label->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:20pt; font-weight:700; color:#ff8c00;\">Today's Accuracy:</span></p></body></html>", nullptr));
        today_accuracy->setText(QString());
        howLabel->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-weight:700;\">Here's how it works...</span></p></body></html>", nullptr));
        label_5->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:16pt; font-weight:700; color: #ffffff;\">Step 1:</span><span style=\" font-size:16pt; color: #ffffff;\"> Original Image</span></p></body></html>", nullptr));
        step1pic->setText(QString());
        label_6->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:16pt; font-weight:700; color:#ffffff;\">Step 2:</span><span style=\" font-size:16pt; color:#ffffff;\"> Get Binary image</span></p></body></html>", nullptr));
        step2pic->setText(QString());
        label_7->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:16pt; font-weight:700; color:#ffffff;\">Step 3:</span><span style=\" font-size:16pt; color:#ffffff;\"> Locate digits to crop</span></p></body></html>", nullptr));
        step3pic->setText(QString());
        label_8->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:16pt; font-weight:700; color:#ffffff;\">Step 4:</span><span style=\" font-size:16pt; color:#ffffff\"> Crop each digit into MNIST format</span></p></body></html>", nullptr));
        step4pic1->setText(QString());
        step4pic2->setText(QString());
        step4pic3->setText(QString());
        step4pic4->setText(QString());
        step4pic5->setText(QString());
        step4pic6->setText(QString());
        step4pic7->setText(QString());
        step4pic8->setText(QString());
        step4pic9->setText(QString());
        step4pic10->setText(QString());
        anExample->setText(QCoreApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-weight:700;\">How features are extracted within the Neural Network</span></p></body></html>", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "TextLabel", nullptr));
        label_4->setText(QCoreApplication::translate("MainWindow", "Database", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
